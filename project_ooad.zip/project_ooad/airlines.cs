﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace project_ooad
{
    public partial class airlines : Form
    {
        public airlines()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            reservationf log = new reservationf();
            this.Close();
            log.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            flights m = new flights();
            m.Show();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_BindingContextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            string filename = "test1.txt";

            string listboxData = "";

            foreach (string str in checkedListBox1.CheckedItems)
            {
                  System.IO.StreamWriter objWriter;
            objWriter = new System.IO.StreamWriter(filename, true);
                listboxData += str + "\n";
                File.AppendAllText((Path.Combine(filename,"test1.txt")), str);

            }


            //file.WriteAllText(filename, listboxData);
            //MessageBox.Show("Details have been saved");
            
            /*  string filename = "test2.txt";

   System.IO.StreamWriter objWriter;
  objWriter = new System.IO.StreamWriter(filename, true);

  using (objWriter = new StreamWriter("test1.txt", true))
  {
      objWriter.Write();
  }
  */

        }

        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
           /* string path = "<path to file>";

            foreach (ListItem item in checkedListBox1.CheckedItems)
                if (item.Selected)
                    File.AppendAllText(path, item.Value);*/




        }

        private void airlines_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
