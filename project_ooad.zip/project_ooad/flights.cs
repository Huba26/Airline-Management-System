﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_ooad
{
    public partial class flights : Form
    {
        public flights()
        {
            InitializeComponent();
        }

        private void flights_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            airlines m = new airlines();
            m.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("All the details have been saved\n thankyou for using this reservation system");
            Application.Exit();
        }
    }
}
