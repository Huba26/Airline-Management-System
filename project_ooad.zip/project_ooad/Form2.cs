﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace project_ooad
{
    public partial class reservationf : Form
    {
        public reservationf()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            this.Close();
            log.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            airlines m = new airlines();
            m.Show();

            string file_name = "e:\\test1.txt";

            System.IO.StreamWriter objWriter;
            objWriter = new System.IO.StreamWriter(file_name, true);

            using ( objWriter = new StreamWriter("test1.txt",true))
            {
                objWriter.WriteLine(textBox1.Text);
                objWriter.WriteLine(textBox2.Text);
                objWriter.WriteLine(textBox3.Text);
                objWriter.WriteLine(textBox4.Text);
                
                objWriter.WriteLine(textBox5.Text);

                MessageBox.Show("Details have been saved");
            }
            objWriter.Close();
            /*TextWriter tw = new StreamWriter("test1.txt");

            //Write to file
            tw.WriteLine(textBox1.Text);
            MessageBox.Show("Details have been saved");
            //Close File
            tw.Close();*/
        }
      
    }
}
